# ALIFE 2026 v17 editor package

This package is for a human editor with a PhD in mathematics who is helping convert the v17 paper into an ALIFE 2026 Late-Breaking Abstract.

Primary file to edit:
- `paper_alife2026_v17_for_edit.tex`

Context files:
- `full_context_paper_v17.tex`
- `full_context_paper_v17.pdf`

What this submission is:
- ALIFE 2026 **Late-Breaking Abstract**
- **maximum 2 pages, not including references**
- intended for **poster presentation only**
- suitable for **new ideas and work in progress**

What to optimize:
- readability
- sentence flow
- reduction of robotic phrasing
- stronger transitions
- clearer motivation for an ALIFE audience
- more natural scientific prose

What not to change unless necessary:
- equations
- notation
- theorem substance
- empirical claims
- figure math

If something technical seems unclear, comment on it instead of rewriting the mathematics.

Official ALIFE 2026 source used for this package:
- https://2026.alife.org/call-for-papers/
