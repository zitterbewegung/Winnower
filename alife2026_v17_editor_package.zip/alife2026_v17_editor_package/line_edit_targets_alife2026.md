# Highest-priority line-edit targets

These are the places most likely to sound robotic.

## 1. Opening sentence
Current:
> Cellular automata often form broad periodic domains together with defects, particles, and interfaces.

Editing goal:
Make this vivid and natural, but still concise.

## 2. Problem statement
Current:
> Those domains are visually obvious in many rules, but choosing which global period best explains a finite spacetime is less obvious.

Editing goal:
This is good structurally, but could sound more human and less repetitive.

## 3. Method sentence
Current:
> Each candidate period/shift pair is treated as a model class, fit to its nearest periodic background by majority vote on orbit classes, and scored with a Bernoulli normalized maximum likelihood (NML) criterion.

Editing goal:
This sentence carries too much load at once. It should probably be split.

## 4. Penalty explanation
Current:
> That penalty matters because along velocity-matched divisibility chains, larger templates can only improve raw residual and raw likelihood.

Editing goal:
Keep the mathematics, but make the causal point easier to follow.

## 5. Findings paragraph
Current:
> Across the current 1D, 2D, and 3D case studies, the selected period either stabilizes immediately or changes only a small number of times before locking.

Editing goal:
This is informative but a little stiff. Make it read more naturally.

## 6. Long list sentence
Current:
> Rule 54 stabilizes at period 4 from the first measured horizon; Rule 110 passes through a short transient before locking at period 4 under the period-first selector; S24/B11 in 2D later shifts from period 1 to period 2; and the tested 3D diamoeba rule remains at period 1 throughout the observed range.

Editing goal:
The content is good, but this sentence is too long for a two-page abstract.

## 7. Margin-growth sentence
Current:
> After locking, the winning margin grows rather than shrinks, which matches the model-selection picture behind the full paper.

Editing goal:
Shorten and sharpen.

## 8. ALIFE significance paragraph
Current:
> The method is deliberately modest.

Editing goal:
This opening is fine intellectually, but it sounds defensive. Make it sound confident without overstating.

## 9. Final sentence
Current:
> That makes it useful for large surveys and for follow-on analysis of particles, defects, and coherent structures.

Editing goal:
Good content, but it can be made more compelling.
