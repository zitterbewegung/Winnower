# ALIFE 2026 review checklist for the human editor

## Keep
- 2-page Late-Breaking Abstract structure
- phenomenon-first opening
- one algorithm figure
- one empirical summary figure
- concise references

## Improve
- sentence rhythm
- paragraph flow
- transitions between Motivation, Method, Findings, and Why this matters for ALIFE
- natural wording in captions
- reduction of stacked noun phrases

## Avoid
- adding new technical claims
- expanding proofs
- changing equations unless a typo is found
- turning the abstract back into a journal-style mini-paper
- making the prose more ornate than necessary

## Final pass
Before returning the draft, please check:
- Does the first paragraph sound like a human wrote it?
- Is every long sentence either split or simplified?
- Does the abstract still fit the ALIFE poster track?
- Is the ALIFE significance clear even to a fast reader?
