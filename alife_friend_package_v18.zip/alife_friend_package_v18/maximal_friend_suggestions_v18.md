# Maximal Suggestions for the Friend Readability Pass

This is the fullest version of what would help.

## A. What the paper should sound like

The ideal tone is:
- like a polished CS / complex-systems paper
- less like internal theorem notes
- less repetitive
- less stiff
- more “showing the reader the idea” and less “declaring contributions” every paragraph

## B. What the reader should feel after page 1

By the end of page 1, the paper should feel like:
- it studies emergent periodic domains in CA spacetime
- it proposes a concrete selection method
- the mathematics supports the method rather than crowding out the story
- the author knows exactly what is and is not novel

## C. Most common sentence-level issues still present

1. Noun-heavy openings.
2. Repeated use of abstract nouns like “framework”, “contribution”, “theory”, “picture”, and “structure”.
3. Long sentences with two or three claims compressed together.
4. Paragraphs that end with a scoped qualification rather than a strong landing.
5. Section openings that sound like notes to self rather than polished exposition.

## D. Most useful kinds of edits

- split long sentences
- replace passive or nominalized constructions with cleaner verbs
- reduce metadiscourse such as “this perspective leads to...” when a simpler sentence would do
- vary sentence rhythm
- make the prose a little warmer without becoming casual

## E. Places where stronger prose matters more than precision polish

- abstract opening
- intro paragraph 1
- intro paragraph 2
- transition into contributions
- first paragraph of experiments
- first paragraph of discussion
- last paragraph of conclusion

## F. What not to worry about

Do not spend time trying to improve every proof sentence. That is lower value than smoothing the narrative sentences around the math.
