# Highest-Priority Sections for Readability Editing

## 1. Abstract

Why it matters:
- sets reviewer tone immediately
- should feel phenomenon-first, not theorem-first

What to improve:
- make the theory summary read a little less like a theorem inventory
- keep the final paragraph brisk and confident without sounding inflated

## 2. Introduction

Why it matters:
- this is where ALIFE reviewers decide what kind of paper it is
- it should read like a paper about emergent structure, not just about theorem statements

What to improve:
- paragraph transitions
- repeated use of “global” / “selector” / “contribution”
- any sentence that sounds too compressed or overqualified

## 3. Discussion + Conclusion

Why it matters:
- this is where the paper becomes memorable
- right now the content is strong, but some lines still read more like internal notes than polished prose

What to improve:
- make the claims feel crisp and human
- keep the novelty boundary clear without repeating it too mechanically
- keep the ALIFE significance visible
