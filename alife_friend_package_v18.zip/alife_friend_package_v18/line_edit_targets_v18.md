# Additional Line-Edit Targets

This file points to the places most likely to benefit from a readability pass.

## Abstract

- “each candidate background is represented by a relative-periodic orbit partition”
  - still slightly stiff; could be made lighter without losing meaning
- “velocity-matched divisibility exactly characterizes”
  - accurate, but heavy in an abstract
- “finite-transient corollary”
  - maybe acceptable technically, but reads dry

## Introduction

- “Our goal sits between them”
  - good idea, but perhaps could read more naturally
- “This perspective leads to a simple ALIFE-relevant claim”
  - sounds formal and a bit programmatic
- “tractable global selector”
  - okay, but repeated “global selector” language can feel mechanical

## Section 2 lead-ins

- “This is the orbit-class reduction”
  - can sound note-like; perhaps “We refer to this simplification as the orbit-class reduction.”
- “This is the main theoretical result.”
  - functional, but maybe too abrupt
- “The contribution here is not the proof technique but the instantiation...”
  - good content, but long

## Experiment section

- interpretation sentences after each table can sometimes be split into two shorter sentences
- repeated uses of “consistent with Theorem 3” and “consistent with the predicted tradeoff” may be worth varying
- places where margins, rates, and penalties are all mentioned in one sentence can become dense fast

## Discussion

- “The manuscript is strongest when its claims are scoped precisely.”
  - useful sentence, but maybe a little meta
- “This also explains why the paper should be read as...”
  - might benefit from a more direct rewrite
- “This division of labor is more plausible computationally...”
  - good point; could be made a little smoother

## Conclusion

- the first paragraph is strong but still slightly formal
- the last paragraph should sound memorable rather than carefully hedged
