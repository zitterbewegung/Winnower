# Friend Edit Checklist

## If you only have 10 minutes

- Edit the abstract.
- Edit the first 4 paragraphs of the introduction.
- Edit the conclusion.

## If you have 20–30 minutes

- Also smooth the openings of Sections 3, 4, and 5.
- Trim repeated uses of phrases like “the framework”, “the contribution”, “the theory”, “the selector”.
- Flag any sentence that sounds like a grant proposal or theorem announcement rather than natural paper prose.

## If you have more time

- Read the discussion section for tone consistency.
- Mark places where the prose becomes more formal than necessary.
- Suggest where two short sentences would read better than one long one.
