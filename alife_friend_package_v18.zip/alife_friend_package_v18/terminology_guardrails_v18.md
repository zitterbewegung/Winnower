# Terminology Guardrails

These terms should generally stay intact unless the surrounding sentence is being lightly smoothed:

- orbit class / orbit-class
- residual mask / defect mask
- Bernoulli NML
- period-first selector
- velocity-matched divisibility
- relative-periodic
- Hamming residual
- computational mechanics

## Avoid changing

- theorem numbering
- definition numbering
- notation such as $p$, $\mathbf{s}$, $\lambda_c$
- references to specific rules or datasets

## Safe to change

- sentence openings
- transition phrases
- repeated uses of “the framework”, “the contribution”, “the method”, “the selector”
- paragraph closers that sound stiff
