# ALIFE Friend Readability Package

This package is meant for a language-and-flow edit, not a mathematical rewrite.

## Best order to review

1. Read `email_to_friend_v18.txt` to see the exact request.
2. Skim `friend_edit_brief_v18.md` for goals and guardrails.
3. Read `paper_v18_friend_readability.md` with your attention mainly on:
   - Abstract
   - Introduction
   - Section openings and transitions
   - Discussion
   - Conclusion
4. Use `priority_sections_v18.md` and `line_edit_targets_v18.md` if you want a faster targeted pass.
5. Use `top_10_robotic_sentences_v18.md` to calibrate tone.

## What this package is for

The paper is already structurally rewritten for ALIFE. The remaining job is to make it sound more natural, less robotic, and easier to read without changing the mathematics.

## Please focus on

- sentence flow
- paragraph flow
- transitions between sections
- repetition reduction
- making the prose sound like natural scientific writing

## Please do not focus on

- reworking proofs
- changing theorem numbering
- changing equations or definitions
- altering claims unless something really sounds too strong, in which case please leave a note
