# Friend Edit Brief

## What I need from this pass

This is a **language and readability edit**, not a mathematical edit.

The manuscript is already technically strong enough for its target venue. What it still needs is a more natural tone and better flow.

## Main goals

1. Make the writing sound less robotic.
2. Shorten long or heavy sentences.
3. Improve transitions between paragraphs and sections.
4. Reduce repeated phrasing.
5. Keep the tone as natural scientific prose rather than theorem-first formal prose.

## What not to change

- equations
- definitions
- theorem numbers
- claim scope, unless something clearly sounds overstated
- notation such as orbit class, residual mask, Bernoulli NML, period-first selector

## What to do instead of rewriting math

If a technical passage feels hard to read, please either:
- smooth the surrounding prose, or
- leave a margin note / comment saying the sentence is too dense

## Tone target

Good target tone:
- clear
- calm
- direct
- compact but readable
- scientific, not chatty
- less repetitive and less “this paper proves X” sounding

## Highest-value places to edit

- Abstract
- Introduction
- first paragraph of each major section
- interpretation sentences after tables
- Discussion
- Conclusion
