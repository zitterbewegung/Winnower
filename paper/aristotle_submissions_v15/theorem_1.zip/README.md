# Theorem 1: Optimal Hamming Projection

Use `paper_v15.md` as the source of truth for this prompt.
Use `manuscript_excerpt.tex` only to compare the ALIFE submission wording.

## What to do

1. Paste `prompt.md` into Aristotle using `Direct Aristotle in English` mode.
2. Attach `../shared_context/paper_v15.md`.
3. Submit.
4. Save the returned Lean file.
5. Run `lake build` or compile the file directly.
6. Record the exact theorem statement and any weakening in `../shared_context/CLAIM_LEDGER.md`.

## Files in this bundle

- `prompt.md`
- `manuscript_excerpt.tex`
- `notes.md`

## Claim metadata

- Priority: 3
- Dependencies: none
- Notes: Clean finite combinatorics. Good sanity-check target.
